import React, { Component } from 'react'
import './StaticHome.css';
export class Statichome extends Component {
    render() {
        return (
            <div className="jumbotron">
            <div className="container">
                 <h1 className="display-4">Welcome to Brillio Fashions</h1>
                 <p className="lead">Explore Different Fashion Trends</p>
                 <p class="lead">
                        <a className="btn btn-primary btn-lg" href="/viewproducts" role="button">View Products</a>
                 </p>
            </div>
            </div>
        )
    }
}

export default Statichome;
