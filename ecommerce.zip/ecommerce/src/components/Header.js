import React from 'react';
import './Header.css';
import {Link} from 'react-router-dom'
function Header() {
    return (

            <nav className="navbar navbar-expand-lg navbar-dark ">
                <div className="container-fluid">
                    <a href="/" className="navbar-brand">Brillio Fashions</a>
                </div>
                <ul className="navbar-nav mr-auto">
                    <Link to="viewproducts" className="nav-link active nav-right">View Products</Link>
                    <Link to="cart" className="nav-link active">Cart</Link>
                    <Link to="login" className="nav-link active">Login</Link>
                </ul> 
            </nav> 

    )
}

export default Header
