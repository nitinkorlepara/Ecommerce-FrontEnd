import React, { Component } from 'react'
import Statichome from './components/Statichome';

export class App extends Component {
  render() {
    return (
      <div>
        <Statichome></Statichome>
      </div>
    )
  }
}

export default App
